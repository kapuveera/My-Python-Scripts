########################################################################
# File: ipsec_vpn_create.py
# Designed and developed by: Tinniam V Ganesh
# Date : 8 Jul 2015
# Email : tv_ganesh@in.ibm.com
#
#########################################################################
import paramiko
command = """
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper begin
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec ipsec-interfaces interface eth1
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper show vpn ipsec ipsec-interfacesset vpn ipsec ike-group IKE-1W proposal 1
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec ike-group IKE-1W proposal 1 encryption ike_p1_encryption
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec ike-group IKE-1W proposal 1 hash ike_p1_hash 
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec ike-group IKE-1W proposal 1 dh-group ike_p1_dh_group
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec ike-group IKE-1W proposal 2 encryption ike_p2_encryption
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec ike-group IKE-1W proposal 2 hash ike_p2_hash
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec ike-group IKE-1W proposal 2 dh-group ike_p2_dh_group
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec ike-group IKE-1W lifetime ike_lifetime
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper show vpn ipsec ike-group IKE-1W
    
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec esp-group ESP-1W proposal 1
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec esp-group ESP-1W proposal 1 encryption esp_p1_encryption
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec esp-group ESP-1W proposal 1 hash esp_p1_hash
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec esp-group ESP-1W proposal 2 encryption esp_p2_encryption
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec esp-group ESP-1W proposal 2 hash esp_p2_hash
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec esp-group ESP-1W lifetime esp_lifetime
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper show vpn ipsec esp-group ESP-1W
    
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec site-to-site peer peer_ip authentication mode pre-shared-secret
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec site-to-site peer peer_ip authentication pre-shared-secret vpn_secret
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec site-to-site peer peer_ip default-esp-group ESP-1W
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec site-to-site peer peer_ip  ike-group IKE-1W
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec site-to-site peer peer_ip  local-address  local_public_ip
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec site-to-site peer peer_ip  tunnel 1 local prefix local_private_ip/32
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn ipsec site-to-site peer peer_ip  tunnel 1 remote prefix remote_private_ip/32
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper commit
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper save
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper show vpn ipsec site-to-site peer peer_ip 
    """

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
print "Logging in ..."
ssh.connect('ip_address', username='vyatta', password = 'pwd')
print "Configuring IPSec VPN on Vyatta ..."
stdin,stdout,stderr=ssh.exec_command(command)
print ''.join(stdout)
ssh.close()




