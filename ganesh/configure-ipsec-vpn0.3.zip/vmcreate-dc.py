#################################################################
# File: vmcreate-dc.py
# Designed and developed by: Tinniam V Ganesh
# Date : 8 Jul 2015
# Email : tv_ganesh@in.ibm.com
#
#########################################################################
import sys
import SoftLayer
# For nice debug output:
from pprint import pprint as pp

f1 = open("./account.txt","r")
api_username = f1.readline().rstrip()
api_key = f1.readline().rstrip()

print "API Username : " + api_username
print "API Key : " + api_key

client = SoftLayer.Client(
    username=api_username,
    api_key=api_key 
)

f1.close()

val = []
# Read from appropriate DC file the login and IP address details

file1 = "./vm-cfg.txt"
# Read cfg file 
with open(file1) as f:
    # Skip 18 lines
    for _ in xrange(18):
        next(f)
    # Read all the lines and append to list
    for line in f:
       val.append(line.rstrip())
       
dc = val[0]
domain = val[1]
hourlyFlag = val[2]
localDiskOption= val[3]
maxMemory = val[4]
hostName = val[5]
startCPU = val[6]
os = val[7]

print "\n"
print "Configuration details"
print "Datacenter: " + dc
print "Domain: " + domain
print "Hourly Flag: " + hourlyFlag
print "Local Disk Flag: " + localDiskOption
print "Max memory : " + maxMemory
print "Hostname: "  + hostName
print "CPU: " + startCPU
print "OS: " + os
print "\n"
print "Configuring VM at " + dc

# Configure the  order Template
orderTemplate = {
      'datacenter': {
        'name': dc
      },
      'domain': domain,
      'hourlyBillingFlag': hourlyFlag,
      'localDiskFlag': localDiskOption,
      'maxMemory': maxMemory,
      'hostname': hostName,
      'startCpus': startCPU,
      'operatingSystemReferenceCode': os
    }

try:
    result = client['SoftLayer_Virtual_Guest'].createObject(orderTemplate)
    pp(result)
except Exception as e:
    pp('Failed ............', e)
