########################################################################
# File: replace_ip_log.py
# Designed and developed by: Tinniam V Ganesh
# Date : 8 Jul 2015
# Email : tv_ganesh@in.ibm.com
#
#########################################################################
import sys
val = []
i=0

# Read from appropriate DC file the login and IP address details
file1 = "./vm" + sys.argv[1] + "-ip-login.txt"
print "Reading from file: " + file1
with open(file1) as f:
    # Skip 31 lines
    for _ in xrange(31):
        next(f)
    # Read all the lines and append to list
    for line in f:
       val.append(line.rstrip())
       
        
# Assign values from the file
ip = val[0]
passwd = val[1]
peer_public_ip = val[2]
local_pub_ip = val[3]
local_priv_ip = val[4]
remote_priv_ip = val[5]
# Read IKE parameters
ike_p1_encryption = val[7]
ike_p1_hash = val[8]
ike_p1_dh_group = val[9]
ike_p2_encryption = val[10]
ike_p2_hash = val[11]
ike_p2_dh_group = val[12]
ike_lifetime = val[13]
#Read ESP parameters
esp_p1_encryption = val[15]
esp_p1_hash = val[16]
esp_p2_encryption = val[17]
esp_p2_hash = val[18]
esp_lifetime = val[19]
# Read pre-shared secret
vpn_secret = val[21]
            

# Close file
f.close()

# Substitute the values
file2 = "ipsec-vpn-create-" + sys.argv[1] + "-sl.py"
print "Writing to output file: " + file2
o = open(file2,"w") #open for write

# Substitute above read values in ipsec-vpn-create.py
for line in open("ipsec-vpn-create.py"):
    line = line.replace("ip_address",ip)
    line = line.replace("pwd",passwd)
    line = line.replace("pwd",passwd)
    line = line.replace("peer_ip",peer_public_ip)
    line = line.replace("local_public_ip",local_pub_ip)
    line = line.replace("local_private_ip",local_priv_ip)
    line = line.replace("remote_private_ip",remote_priv_ip)
    # IKE 
    line = line.replace("ike_p1_encryption",ike_p1_encryption)
    line = line.replace("ike_p1_hash",ike_p1_hash)
    line = line.replace("ike_p1_dh_group",ike_p1_dh_group)
    line = line.replace("ike_p2_encryption",ike_p2_encryption)
    line = line.replace("ike_p2_hash",ike_p2_hash)
    line = line.replace("ike_p2_dh_group",ike_p2_dh_group)
    line = line.replace("ike_lifetime",ike_lifetime)
    # ESP
    line = line.replace("esp_p1_encryption",esp_p1_encryption)
    line = line.replace("esp_p1_hash",esp_p1_hash)
    line = line.replace("esp_p2_encryption",esp_p2_encryption)
    line = line.replace("esp_p2_hash",esp_p2_hash)
    line = line.replace("esp_lifetime",esp_lifetime)
    # Secret
    line = line.replace("vpn_secret",vpn_secret)


    
    o.write(line)
o.close()
