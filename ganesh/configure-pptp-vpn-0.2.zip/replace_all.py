###############################################################
# File:replace_all.py
# Replaces IP address and password
# Designed and developed by : Tinniam V Ganesh
# Email: tv_ganesh@in.ibm.com
# Date: 03 Jul 2015
###############################################################
f = open("./vm-details.txt","r")
ip = f.readline().rstrip()
passwd = f.readline().rstrip()

o = open("pptp-vpn-create-sl.py","w") #open for write
for line in open("pptp-vpn-create.py"):
    line = line.replace("ip_address",ip)
    line = line.replace("pwd",passwd)
    o.write(line)
o.close()
