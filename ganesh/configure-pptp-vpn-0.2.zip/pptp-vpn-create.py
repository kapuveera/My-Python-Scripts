###############################################################
# File:pptp-vpn-create.py
# This python script creates PPTP VPN on SL with paramiko
# and use vyatta-cfg-command-wrapper
# Designed and developed by : Tinniam V Ganesh
# Date: 03 Jul 2015
# Email: tv_ganesh@in.ibm.com
###############################################################
import paramiko

print "Configuring..."
command = """
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper begin
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn pptp remote-access client-ip-pool start 10.66.14.146
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn pptp remote-access client-ip-pool stop 10.66.14.150
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn pptp remote-access authentication mode local
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn pptp remote-access authentication mode local
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn pptp remote-access authentication local-users username poctest password poctest
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper set vpn pptp remote-access outside-address  ip_address
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper show vpn pptp remote-access outside-address  ip_address
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper commit
    /opt/vyatta/sbin/vyatta-cfg-cmd-wrapper save
    """

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy()) 
ssh.connect('ip_address', username='vyatta', password = 'pwd')
stdin,stdout,stderr=ssh.exec_command(command)
print ''.join(stdout)
ssh.close()
