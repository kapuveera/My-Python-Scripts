import SoftLayer
import pprint

f = open("./account.txt","r")
api_username = f.readline().rstrip()
api_key = f.readline().rstrip()

print "API Username : " + api_username
print "API Key : " + api_key

client = SoftLayer.Client(username=api_username, api_key=api_key, endpoint_url=SoftLayer.API_PUBLIC_ENDPOINT)
mask = 'vlanNumber, primaryRouter.hostname, subnets.networkIdentifier, subnets.cidr'
allVlans = client['Account'].getNetworkVlans(mask=mask)
pprint.pprint(allVlans)
