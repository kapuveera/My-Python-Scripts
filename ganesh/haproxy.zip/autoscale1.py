import SoftLayer
f = open("./account.txt","r")
api_username = f.readline().rstrip()
api_key = f.readline().rstrip()
definition = {
        "cooldown": 30,
        "maximumMemberCount": 1,
        "maximumVirtualGuestMemberCount": 1,
        "minimumMemberCount": 1,
        "minimumVirtualGuestMemberCount": 1,
        "name": "myautoscale",
        #"networkVlans": [ { "id": 898499 }, { "id": 898497 } ],
        #"regionalGroupId": 344,
        "suspendedFlag": True,
        "terminationPolicyId": 1,
        "virtualGuestMemberTemplate": {
            "datacenter": { "name": "sng01" },
            "domain": "autoscale.softlayer.com",
            "hostname": "tvganesh",
            "hourlyBillingFlag": True,
            "localDiskFlag": False,
            "maxMemory": 1024,
            "operatingSystemReferenceCode": "UBUNTU_LATEST_64",
            #"sshKeys": [ { "id": 273191 } ],
            "startCpus": 1
            }
        }

#client = SoftLayer.create_client_from_env(username=api_username,api_key=api_key)
client = SoftLayer.Client(username=api_username,api_key=api_key)
client['Scale_Group'].createObject(definition)
