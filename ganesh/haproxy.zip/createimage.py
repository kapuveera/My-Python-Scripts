#######################################################################################
#
# Designed and developed by : Tinniam V Ganesh
# Date: 17 Jul 2015
# Create an image of a CCI
#
#########################################################################################
import SoftLayer
# For nice debug output:
from pprint import pprint as pp


f = open("./account.txt","r")
api_username = f.readline().rstrip()
api_key = f.readline().rstrip()

print "Creating ..."
# Declare APi Client
client = SoftLayer.Client(username=api_username, api_key=api_key)

# Declare Id from Virtual Guest. You can retrieve all the Virtual Guests using SoftLayer_Account::getVirtualGuests method
vsiId = 11011487

# Define object mask to view which disk is SWAP
object_mask = "mask[diskImage[name]]"

# Define filter for filtering the swap disk
filter = {'blockDevices': {'diskImage': {'name': {'operation': '!~SWAP'}}}}
disks = client['SoftLayer_Virtual_Guest'].getBlockDevices(mask=object_mask, filter=filter, id=vsiId)

try:
    result = client['SoftLayer_Virtual_Guest'].createArchiveTransaction("NodeExp Mongodb Final",disks, "test", id=vsiId)
    pp(result)
except SoftLayer.SoftLayerAPIError as e:
    print("Unable to create image template: ")
        #% (e.faultString))
              #% (e.faultCode, e.faultString))
