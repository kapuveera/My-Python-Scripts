# Gets the CCI Id given the string of the domain 'haproxy'

import SoftLayer
from pprint import pprint as pp

f = open("./account.txt","r")
api_username = f.readline().rstrip()
api_key = f.readline().rstrip()

# Declare APi Client
client = SoftLayer.Client(username=api_username, api_key=api_key)
guest = client['Account'].getVirtualGuests(filter={'virtualGuests': {'domain': {'operation': '*= server3'}}})

# Print the guest.
pp(guest)
