# Gets the CCI Id given the string of the domain 'haproxy'

import SoftLayer
from pprint import pprint as pp

f = open("./account.txt","r")
api_username = f.readline().rstrip()
api_key = f.readline().rstrip()

# Declare APi Client
client = SoftLayer.Client(username=api_username, api_key=api_key)
obj = client['Product_Package'].getAllObjects(mask='name')


# Print the guest.
pp("Print all objects")
print "\n"
pp(obj)

print "\n"
pp("Getting account object")
print "\n"
a = client['Account'].getObject()
pp(a)

print "\n"
pp("Getting Billing Info")
print "\n"
a = client['Account'].getBillingInfo()
pp(a)

print "\n"
pp("Get Network VLANs")
print "\n"
a = client['Account'].getNetworkVlans(
    filter={'virtualGuests': {'id': {'operation': '*= server3'}}})
pp(a)
