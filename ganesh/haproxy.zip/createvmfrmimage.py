######################################################################################
#
# Designed and developed by : Tinniam V Ganesh
# Date: 17 Jul 2015
# Create an image of a CCI
#
#########################################################################################
import SoftLayer
# For nice debug output:
from pprint import pprint as pp

f = open("./account.txt","r")
api_username = f.readline().rstrip()
api_key = f.readline().rstrip()

# Declare APi Client
client = SoftLayer.Client(username=api_username, api_key=api_key)

# Declare the name 
nameImage = 'NodeExp Mongodb Final'

# Declare the name of the image template, they are displayed in https://control.softlayer.com/devices/images (Standard Image) 
# or use the following method to retrieve all of them SoftLayer_Account::getBlockDeviceTemplateGroups
filter = {'blockDeviceTemplateGroups': {'name': {'operation': '_=' + nameImage}}}
globalIdentifier = client['SoftLayer_Account'].getBlockDeviceTemplateGroups(filter=filter)

# Build SoftLayer_Virtual_Guest object to create a Virtual Guest. 
# Try the following method for more options: SoftLayer_Virtual_Guest::getCreateObjectOptions
templateObject = {
                 "hostname": "tvganesh3",
                 "domain": "server3.softlayer.com",
                 "datacenter": {
                                "name": "sng01"
                               },
                 "startCpus": 1,
                 "maxMemory": 1,
                 "hourlyBillingFlag": "true",
                 "localDiskFlag": "false",
                 'networkComponents': [{'maxSpeed': '1000'}],
                 "blockDeviceTemplateGroup": {
                                              "globalIdentifier": globalIdentifier[0]['globalIdentifier']
                                              }
                 }
try:
    result = client['SoftLayer_Virtual_Guest'].createObject(templateObject)
    pp(result)
except SoftLayer.SoftLayerAPIError as e:
    print("Unable to create Virtual Guest: "
              % (e.faultCode, e.faultString))
