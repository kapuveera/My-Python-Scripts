import SoftLayer
# For nice debug output:
from pprint import pprint as pp


f = open("./account.txt","r")
api_username = f.readline().rstrip()
api_key = f.readline().rstrip()

print "API Username : " + api_username
print "API Key : " + api_key

client = SoftLayer.Client(
    username=api_username,
    api_key=api_key 
)

f = open("./vm.txt","r")
dc = f.readline().rstrip()
domain = f.readline().rstrip()
hourlyFlag = f.readline().rstrip()
localDiskOption= f.readline().rstrip()
maxMemory = f.readline().rstrip()
hostName = f.readline().rstrip()
startCPU = f.readline().rstrip()
os = f.readline().rstrip()

print "Datacenter: " + dc
print "Domain: " + domain
print "Hourly Flag: " + hourlyFlag
print "Local Disk Flag: " + localDiskOption
print "Max memory : " + maxMemory
print "Hostname: "  + hostName
print "CPU: " + startCPU
print "OS: " + os

print "Configuring ..."

# Configure the  order Template
orderTemplate = {
      'datacenter': {
        'name': dc
      },
      'domain': domain,
      'hourlyBillingFlag': hourlyFlag,
      'localDiskFlag': localDiskOption,
      'maxMemory': maxMemory,
      'hostname': hostName,
      'startCpus': startCPU,
      'operatingSystemReferenceCode': os
    }

try:
    result = client['SoftLayer_Virtual_Guest'].createObject(orderTemplate)
    pp(result)
except Exception as e:
    pp('Failed ............', e)
